# AWS 배포

### EC2

- 확장이 용이
- AMI(Amazom Machine Image)를 기반으로 다양한 인스턴스 제공



### Amazon S3  

- 데이터 스토리지 솔루션
- 바이너리 파일 등의 데이터 저장
- 하드디스크

![image-20210809090617609](C:\Users\multicampus\AppData\Roaming\Typora\typora-user-images\image-20210809090617609.png)

- DB까지는 도커화를 시키지 않아도 괜찮다.
- Nginx를 사용하는 이유는?
  - 예전에는 tomcat위에다가 같이 묶어서 올리는 방법을 사용
  - nginx가 정적인 파일을 서비스 할 때 tomcat보다 성능이 좋다



![image-20210809091019496](C:\Users\multicampus\AppData\Roaming\Typora\typora-user-images\image-20210809091019496.png)