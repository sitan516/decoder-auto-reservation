# JSON 과 친구들

### JSON

- JSON은 객체와 배열로 이루어져 있음
- 오류나면 JSON Validation check 부터 해봐라



### Jackson



